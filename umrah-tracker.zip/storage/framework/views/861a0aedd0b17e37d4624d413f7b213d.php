<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <title>Umrah Tracker</title>
    <meta name="description" content="Aplikasi pemandu dan pelacak ibadah Umrah mandiri">
    
    <!-- PWA Basic Tags -->
    <meta name="theme-color" content="#1a1a2e">
    <link rel="icon" href="/favicon.ico">

    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.jsx']); ?>
    
    <!-- Leaflet Map -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head>
<body>
    <div id="root"></div>
</body>
</html>
<?php /**PATH D:\laragon\www\umrah-tracker\resources\views/welcome.blade.php ENDPATH**/ ?>